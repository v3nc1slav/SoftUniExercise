﻿namespace Introduction_to_DB_Apps
{
    public static class Configuration
    {
        public const string Connection = "Server=(localdb)\\mssqllocaldb;; Integrated Security = true;";
        public const string ConnectionDatabase = "Server=(localdb)\\mssqllocaldb;DATABASE=MinionsDB; Integrated Security = true;";
    }
}

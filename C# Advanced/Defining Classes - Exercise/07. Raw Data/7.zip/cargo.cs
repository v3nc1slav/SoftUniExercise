﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Cargo
    {
        public int cargoWeight { get; set; }
        public string cargoType { get; set; }
    }
}
 
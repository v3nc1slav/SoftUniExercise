﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Tire
    {
        public double tire1Pressure { get; set; }
        public int tire1Age { get; set; }
        public double tire2Pressure { get; set; }
        public int tire2Age { get; set; }
        public double tire3Pressure { get; set; }
        public int tire3Age { get; set; }
        public double tire4Pressure { get; set; }
        public int tire4Age { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Engine
    {
        public int engineSpeed { get; set; }
        public int enginePower { get; set; }

    }
}

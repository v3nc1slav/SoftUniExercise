﻿namespace WildFarm
{
    using System;

    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new WildFarm.Engine.Engine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IPhones
    {
        string  CallingPhones( string number);
    }
}

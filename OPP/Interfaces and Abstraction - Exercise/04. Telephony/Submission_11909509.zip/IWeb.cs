﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IWeb
    {
        string Browsing(string web);
    }
}

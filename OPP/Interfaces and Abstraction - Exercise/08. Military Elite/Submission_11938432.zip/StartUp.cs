﻿using System;
using System.Linq;
using PersonInfo.MilitaryElite;

namespace PersonInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo.MilitaryElite
{
    public enum State
    {
        inProgress,
        Finished
    }
}

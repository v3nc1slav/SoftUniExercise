﻿namespace PersonInfo.Birthday_Celebrations
{
    public interface IPet
    {
        void Birthdates(string name, string birthday);
    }
}

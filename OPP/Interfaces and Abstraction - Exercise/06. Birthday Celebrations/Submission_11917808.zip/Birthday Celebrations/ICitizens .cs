﻿namespace PersonInfo.Birthday_Celebrations
{
    public interface ICitizens
    {
        void Birthdates(string name, string age, string id, string birthday);
    }
}

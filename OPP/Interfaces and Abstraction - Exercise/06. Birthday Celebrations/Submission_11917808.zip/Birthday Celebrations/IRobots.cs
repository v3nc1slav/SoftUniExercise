﻿namespace PersonInfo.Birthday_Celebrations
{
    public interface IRobots
    {
        void Birthdates(string model, int id);
    }
}

﻿namespace PersonInfo.FoodShortage
{
    public interface IRobots
    {
        void Implement(string model, int id);
    }
}

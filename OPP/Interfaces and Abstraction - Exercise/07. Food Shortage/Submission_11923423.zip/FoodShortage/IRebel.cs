﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo.FoodShortage
{
    public interface IRebel
    {
        void Implement(string name, string age, string grup);
    }
}

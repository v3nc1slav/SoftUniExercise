﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo.FoodShortage
{
    public interface IBuyer
    {
        void BuyFood(string name);
    }
}

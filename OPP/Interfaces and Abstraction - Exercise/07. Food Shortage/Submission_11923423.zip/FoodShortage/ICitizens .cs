﻿namespace PersonInfo.FoodShortage
{
    public interface ICitizens
    {
        void Implement(string name, string age, string id, string birthday);
    }
}

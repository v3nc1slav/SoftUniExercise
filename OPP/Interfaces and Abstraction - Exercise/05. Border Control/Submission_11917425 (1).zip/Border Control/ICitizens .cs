﻿namespace PersonInfo.Border_Control
{
    public interface ICitizens
    {
        void Control(string name, string age, string id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo.Border_Control
{
    public interface IRobots
    {
        void Control(string model, string id);
    }
}
